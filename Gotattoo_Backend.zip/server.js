
const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const paypal = require('@paypal/checkout-server-sdk');

const app = express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log('MongoDB connected'))
  .catch((err) => console.log(err));

const userSchema = new mongoose.Schema({
    email: String,
    password: String,
    role: String, // 'artist' or 'client'
});
const User = mongoose.model('User', userSchema);

app.post('/register', async (req, res) => {
    const { email, password, role } = req.body;
    const user = new User({ email, password, role });
    await user.save();
    res.json({ message: 'User registered successfully!' });
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET);
    res.json({ token });
});

const artistSchema = new mongoose.Schema({
    name: String,
    specialty: String,
    portfolio: [String],
});
const Artist = mongoose.model('Artist', artistSchema);

app.get('/artists', async (req, res) => {
    const artists = await Artist.find();
    res.json(artists);
});

const Environment = new paypal.core.SandboxEnvironment(
    process.env.PAYPAL_CLIENT_ID,
    process.env.PAYPAL_SECRET
);
const PayPalClient = new paypal.core.PayPalHttpClient(Environment);

app.post('/create-payment', async (req, res) => {
    const { amount, description } = req.body;
    const request = new paypal.orders.OrdersCreateRequest();
    request.requestBody({
        intent: 'CAPTURE',
        purchase_units: [
            { amount: { value: amount, currency_code: 'USD' }, description },
        ],
    });
    try {
        const order = await PayPalClient.execute(request);
        res.json({ id: order.result.id });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/webhook', (req, res) => {
    console.log(req.body);
    res.status(200).send('Webhook received');
});

app.listen(5000, () => console.log('Server running on port 5000'));
